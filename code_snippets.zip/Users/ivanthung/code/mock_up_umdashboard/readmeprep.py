import os


def gather_code_info(directory):
    """Walks a directory and gathers code files with comments."""
    for root, _, files in os.walk(directory):
        for file in files:
            if file.endswith(
                (".py", ".js", ".java", ".cpp", ".rb")
            ):  # Add more extensions as needed
                filepath = os.path.join(root, file)
                with open(filepath, "r") as f:
                    lines = f.readlines()
                yield filepath, lines


if __name__ == "__main__":
    current_dir = os.getcwd()  # Get the current working directory

    # Result options (Choose one)
    OPTION_1 = "code_info.txt"
    OPTION_2 = "code_snippets.zip"

    # OPTION 1: Write code and comments to a text file
    with open(OPTION_1, "w") as f:
        for filepath, lines in gather_code_info(current_dir):
            f.write("FILE: {}\n".format(filepath))
            for line in lines:
                if line.strip().startswith("#") or line.strip().startswith("//"):
                    f.write(line)

    # OPTION 2: Create a Zip archive with select code files
    import zipfile

    with zipfile.ZipFile(OPTION_2, "w") as zipf:
        for filepath, _ in gather_code_info(current_dir):
            zipf.write(filepath)
